# wake-proxy

WAKE. ROUTE. CONNECT.

A lightweight Wake-on-LAN proxy server.
